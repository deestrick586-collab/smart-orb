(function(){
  const ethers = window.ethers;
  const el = id => document.getElementById(id);
  const status = txt => el('status').textContent = txt;

  let provider, signer;

  const FAUCET_ABI = [
    'function setToken(address _token) external',
    'function claim() external',
    'function amountPerClaim() view returns (uint256)',
    'function claimCooldown() view returns (uint256)',
    'function lastClaimAt(address) view returns (uint256)'
  ];

  const TOKEN_ABI = [
    'function setMinter(address _minter) external',
    'function name() view returns (string)',
    'function symbol() view returns (string)',
  ];

  async function connect(){
    if(!window.ethereum) return alert('MetaMask not found');
    await window.ethereum.request({ method:'eth_requestAccounts' });
    provider = new ethers.providers.Web3Provider(window.ethereum);
    signer = provider.getSigner();
    const addr = await signer.getAddress();
    status('Connected: ' + addr);
  }

  async function link(){
    try{
      const faddr = el('faucetAddr').value.trim();
      const taddr = el('tokenAddr').value.trim();
      if(!faddr || !taddr) throw new Error('Enter both addresses');

      const faucet = new ethers.Contract(faddr, FAUCET_ABI, signer);
      const token  = new ethers.Contract(taddr, TOKEN_ABI, signer);

      // 1) Set faucet token
      await (await faucet.setToken(taddr)).wait();
      // 2) Give faucet minter rights
      await (await token.setMinter(faddr)).wait();

      status('Linked faucet and token successfully.');
    }catch(e){ status('Link error: ' + (e?.message||e)); }
  }

  async function claim(){
    try{
      const faddr = el('faucetAddr').value.trim();
      if(!faddr) throw new Error('Enter faucet address');
      const faucet = new ethers.Contract(faddr, FAUCET_ABI, signer);

      const tx = await faucet.claim();
      status('Claim tx sent: ' + tx.hash);
      const r = await tx.wait();
      status('Claimed in block ' + r.blockNumber);
    }catch(e){ status('Claim error: ' + (e?.message||e)); }
  }

  el('connect').onclick = connect;
  el('link').onclick = link;
  el('claim').onclick = claim;
})();