# Smart Orb Faucet (Testnet)

This faucet mints test ORB to callers (1 claim per 24 hours).

## Deploy (Remix or Hardhat)
1. Deploy `TestSmartOrbToken.sol` (record address)
2. Deploy `SmartOrbFaucet.sol` with constructor `_token = TestSmartOrbToken` address
3. Call `setMinter(faucetAddress)` on the token (owner only)
4. Users call `claim()` from the faucet UI

> For mainnet, do NOT use the mintable test token.
