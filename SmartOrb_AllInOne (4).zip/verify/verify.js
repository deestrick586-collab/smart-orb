#!/usr/bin/env node
/**
 * Simple Hardhat verification helper.
 * Usage: node verify.js <contractAddress> [constructorArgs...]
 */
const { execSync } = require('child_process');

const addr = process.argv[2];
if(!addr) {
  console.error('Usage: node verify.js <contractAddress> [args...]');
  process.exit(1);
}

try {
  const args = process.argv.slice(3);
  const cmd = `npx hardhat verify --network sepolia ${addr} ${args.join(' ')}`;
  console.log('> ', cmd);
  execSync(cmd, { stdio: 'inherit' });
} catch (e) {
  console.error('Verify failed:', e.message);
  process.exit(1);
}
