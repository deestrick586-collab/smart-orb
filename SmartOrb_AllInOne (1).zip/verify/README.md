# Verification Helper

Usage:
```bash
cd verify
node verify.js 0xYourContract
```

Requires: Hardhat configured with `etherscan.apiKey` (or explorer compatible key).
