# Smart Orb — Hardhat Project

## Setup
```bash
cd hardhat
cp .env.example .env
# edit .env with PRIVATE_KEY and keys
npm i
```

## Compile
```bash
npm run compile
```

## Deploy to Sepolia (testnet)
```bash
npm run deploy:sepolia
```

## Deploy to Smart Orb (custom RPC)
```bash
npm run deploy:smartorb
```

**Security:** never commit your `.env` or private keys.
