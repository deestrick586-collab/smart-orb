require('dotenv').config();
require('@nomicfoundation/hardhat-toolbox');

const { PRIVATE_KEY, ALCHEMY_API_KEY, SMART_ORB_RPC } = process.env;

module.exports = {
  solidity: '0.8.20',
  networks: {
    sepolia: {
      url: `https://eth-sepolia.g.alchemy.com/v2/${ALCHEMY_API_KEY || ''}`,
      accounts: PRIVATE_KEY ? [PRIVATE_KEY] : []
    },
    smartorb: {
      url: SMART_ORB_RPC || 'https://rpc.smartorb.network',
      chainId: 12121,
      accounts: PRIVATE_KEY ? [PRIVATE_KEY] : []
    }
  },
  etherscan: {
    apiKey: {
      // optional placeholders
      sepolia: process.env.ETHERSCAN_API_KEY || ''
    }
  }
};
