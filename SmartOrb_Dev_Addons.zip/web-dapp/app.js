(function(){
  const ethers = window.ethers;
  let provider, signer, token;

  const abi = [
    'function name() view returns (string)',
    'function symbol() view returns (string)',
    'function decimals() view returns (uint8)',
    'function balanceOf(address) view returns (uint256)',
    'function transfer(address to, uint256 amount) returns (bool)'
  ];

  async function connect() {
    if (!window.ethereum) {
      alert('MetaMask not found');
      return;
    }
    await window.ethereum.request({ method: 'eth_requestAccounts' });
    provider = new ethers.providers.Web3Provider(window.ethereum);
    signer = provider.getSigner();
    const addr = await signer.getAddress();
    document.getElementById('account').textContent = 'Connected: ' + addr;
  }

  async function loadToken() {
    try {
      const address = document.getElementById('tokenAddress').value.trim();
      token = new ethers.Contract(address, abi, signer);
      const name = await token.name();
      const symbol = await token.symbol();
      const dec = await token.decimals();
      document.getElementById('tokenInfo').textContent = `${name} (${symbol}), decimals: ${dec}`;
    } catch (e) {
      document.getElementById('tokenInfo').textContent = 'Failed to load token: ' + e.message;
    }
  }

  async function send() {
    try {
      const to = document.getElementById('to').value.trim();
      const amt = document.getElementById('amount').value.trim();
      const dec = await token.decimals();
      const value = ethers.utils.parseUnits(amt, dec);
      const tx = await token.transfer(to, value);
      document.getElementById('status').textContent = 'Tx sent: ' + tx.hash;
      const r = await tx.wait();
      document.getElementById('status').textContent = 'Confirmed in block ' + r.blockNumber;
    } catch (e) {
      document.getElementById('status').textContent = 'Error: ' + e.message;
    }
  }

  document.getElementById('connect').onclick = connect;
  document.getElementById('loadToken').onclick = loadToken;
  document.getElementById('send').onclick = send;
})();