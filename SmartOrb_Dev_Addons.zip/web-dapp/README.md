# Smart Orb — Web dApp
A minimal static dApp to connect MetaMask, load your deployed ORB token, and transfer.

## Serve locally
Open `index.html` from a local server (e.g., VSCode Live Server) for best results.
