# Testnet Faucet & Setup

## Sepolia ETH (for testing)
- Alchemy Faucet: https://sepoliafaucet.com/
- QuickNode Faucet: https://faucet.quicknode.com/ethereum/sepolia

## Add Sepolia in MetaMask
Settings → Networks → Add:
- Network Name: Ethereum Sepolia
- RPC URL: Use your provider (e.g., Alchemy/Infura)
- Chain ID: 11155111
- Currency Symbol: ETH
- Block Explorer: https://sepolia.etherscan.io

## Add Smart Orb RPC
Settings → Networks → Add:
- Network Name: Smart Orb Mainnet (Test)
- RPC URL: https://rpc.smartorb.network
- Chain ID: 12121
- Currency Symbol: ORB
- Block Explorer: https://explorer.smartorb.network (optional)
