# 🪐 Smart Orb — All-In-One Bundle

Everything you need to deploy, test, and interact with the Smart Orb (ORB) token.

## Structure
- `contracts/SmartOrbToken.sol` — Enhanced ERC-20 (anti-whale, fee, pause)
- `hardhat/` — Minimal deploy scripts & config (Sepolia + Smart Orb RPC)
- `web-dapp/` — Neon futuristic UI with dark/light mode and auto-network
- `config/network.json` — App auto-switch networks (Smart Orb + Sepolia)
- `docs/` — This README and setup notes
- `LICENSE` — NSP / Dyvon Strickland

## Quick Start (Web dApp)
Open `web-dapp/index.html` via a local server (VSCode Live Server).  
Connect MetaMask → paste deployed token address → transfer ORB.

## Quick Start (Hardhat)
```bash
cd hardhat
npm i
# set PRIVATE_KEY etc. in .env (create manually)
npx hardhat compile
npm run deploy:sepolia    # testnet
npm run deploy:smartorb   # custom chain
```

> Security: never share your seed phrase or commit secrets. For mainnet, prefer audited OpenZeppelin contracts.
