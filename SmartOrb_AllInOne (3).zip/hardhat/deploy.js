const hre = require('hardhat');

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log('Deployer:', deployer.address);
  console.log('Network:', hre.network.name);
  const Token = await hre.ethers.getContractFactory('SmartOrbToken');
  const token = await Token.deploy();
  await token.deployed();
  console.log('SmartOrbToken deployed to:', token.address);
}

main().catch((e)=>{ console.error(e); process.exit(1); });
