(function(){
  const ethers = window.ethers;
  const el = (id) => document.getElementById(id);
  const status = (t) => el('status').textContent = t;

  let provider, signer, token;

  async function setThemeToggle(){
    const key='so-theme';
    const saved = localStorage.getItem(key) || 'dark';
    if(saved==='light') document.documentElement.classList.add('light');
    el('mode').onclick = ()=>{
      document.documentElement.classList.toggle('light');
      localStorage.setItem(key, document.documentElement.classList.contains('light')?'light':'dark');
    };
  }

  async function connect(){
    if(!window.ethereum){ alert('MetaMask not found'); return; }
    await window.ethereum.request({ method:'eth_requestAccounts' });
    provider = new ethers.providers.Web3Provider(window.ethereum);
    signer = provider.getSigner();
    const addr = await signer.getAddress();
    el('account').textContent = 'Connected: ' + addr;

    // Auto-switch logic
    const net = await provider.getNetwork();
    const cfg = await fetch('../config/network.json').then(r=>r.json());
    const nets = cfg.networks;
    const byChainId = (id)=> Object.values(nets).find(n=>Number(n.chainId)===Number(id));

    const active = byChainId(net.chainId);
    if(active){
      status(`Using ${active.name} (chainId ${net.chainId})`);
    } else if(cfg.autoSwitch && nets.smartorb){
      // try request to add Smart Orb
      try{
        await window.ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [{
            chainId: '0x' + Number(nets.smartorb.chainId).toString(16),
            chainName: nets.smartorb.name,
            rpcUrls: [nets.smartorb.rpc],
            nativeCurrency: { name: nets.smartorb.symbol, symbol: nets.smartorb.symbol, decimals: 18 },
            blockExplorerUrls: [nets.smartorb.explorer]
          }]
        });
        status('Smart Orb network added. Switch from MetaMask network selector.');
      }catch(e){
        status('Auto-add network declined. You can still continue on current network.');
      }
    }
  }

  async function loadToken(){
    try{
      if(!signer) await connect();
      const address = el('tokenAddress').value.trim();
      if(!address) throw new Error('Enter token address');
      const abi = [
        'function name() view returns (string)',
        'function symbol() view returns (string)',
        'function decimals() view returns (uint8)',
        'function balanceOf(address) view returns (uint256)',
        'function transfer(address to, uint256 amount) returns (bool)'
      ];
      token = new ethers.Contract(address, abi, signer);
      const [name, symbol, dec] = await Promise.all([token.name(), token.symbol(), token.decimals()]);
      el('tokenInfo').textContent = `${name} (${symbol}), decimals: ${dec}`;
      status('Token loaded.');
    }catch(e){
      el('tokenInfo').textContent = 'Failed to load token: ' + (e?.message||e);
    }
  }

  async function send(){
    try{
      if(!token) throw new Error('Load a token first');
      const to = el('to').value.trim();
      const amt = el('amount').value.trim();
      const dec = await token.decimals();
      const value = ethers.utils.parseUnits(amt, dec);
      const tx = await token.transfer(to, value);
      status('Tx sent: ' + tx.hash);
      const r = await tx.wait();
      status('Confirmed in block ' + r.blockNumber);
    }catch(e){
      status('Error: ' + (e?.message||e));
    }
  }

  el('connect').onclick = connect;
  el('loadToken').onclick = loadToken;
  el('send').onclick = send;
  setThemeToggle();
})();