# 🪐 Smart Orb Workspace (Testnet Setup)

This bundle includes a testnet-safe ERC-20 token (ORB), network configuration, and brand assets.

## Contents
- `contracts/SmartOrbToken.sol` — Enhanced ERC-20 with anti-whale + ecosystem fee
- `config/network.json` — Add this chain to MetaMask
- `assets/smartorb.svg` — Orb logo (transparent SVG)
- `assets/background.png` — Placeholder background (replace as needed)
- `LICENSE` — Limited License (Smart Orb™ / NSP)

## Quick Start (Remix)
1. Open https://remix.ethereum.org
2. Upload `SmartOrbToken.sol` to Remix
3. Compile with **0.8.20**
4. In **Deploy & Run**, choose **Injected Provider - MetaMask**
5. Deploy, then copy contract address to MetaMask → Import Tokens

## Anti-Whale / Fees (Adjustable by owner)
- `maxTxBps` default 200 (2% max per tx)
- `maxWalletBps` default 300 (3% max per wallet)
- `feeBps` default 50 (0.5% fee sent to `rewardsWallet`)
- `pause()` / `unpause()` for safety

> For mainnet, prefer OpenZeppelin-based contracts and a full audit.
